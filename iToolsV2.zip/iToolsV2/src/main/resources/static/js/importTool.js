/*<![CDATA[*/
$( document ).ready(function() {
});

function dowLoadFileImport(logImportId) {
	$.ajax({
        dataType: 'json',
        url: contextPath + '/import/checkExistFileImport',
        data: {logId: logImportId
        },
        success: function (data) {
        	console.log(data);
        	if (data == false) {
        		$("#dialog-Notice").dialog('open');
        	} else {
        		var a = document.createElement('a');
        		a.href = contextPath + '/dowload/' + logImportId;
        	    a.click();
        	}
        }
    });
}

function openTabview(evt, tabViewName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabViewName).style.display = "block";
    evt.currentTarget.className += " active";
}

function uploadFile() {
	// Get form
    var form = $('#FormImport')[0];
    var data = new FormData(form);
    // APPEND FILE TO POST DATA
    $.ajax({
    	dataType: 'json',
        url: contextPath + '/import/loadData',
        type: 'POST',
        contentType: false,
        data: data,
        enctype: 'multipart/form-data',
        //JQUERY CONVERT THE FILES ARRAYS INTO STRINGS.SO processData:false
        processData: false,
        success: function(dataResult) {
        	$('#bodyDataFileImport').html("");
            $.each(dataResult, function (index, obj) {
            	var tr = '<tr>';
            	$.each(obj, function (index, cell) {
            		tr = tr + '<td>' + cell + '</td>';
            	});
                tr = tr + '</tr>';
                $('#bodyDataFileImport').append(tr);
            });
        }
    });
}

function onClickBtSubmit() {
	// validate excel
    var form = $('#FormImport')[0];
    var data = new FormData(form);
	$.ajax({
    	dataType: 'json',
        url: contextPath + '/import/validateExcel',
        type: 'POST',
        contentType: false,
        data: data,
        enctype: 'multipart/form-data',
        //JQUERY CONVERT THE FILES ARRAYS INTO STRINGS.SO processData:false
        processData: false,
        success: function(dataResult) {
        	console.log('aaaaaaaaaa');
        	console.log(dataResult.message);
        	if (dataResult.message == 'TRUE') {
        		document.getElementById("FormImport").submit();
        	} else {
        		alert(dataResult.message);
        	}
        }
    });
	
	
}
/*]]>*/