package com.iToolsV2.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iToolsV2.dao.LogImportDAO;
import com.iToolsV2.entity.LogImport;
import com.iToolsV2.service.ImportToolService;
import com.iToolsV2.utils.ExcellUtils;

import lombok.extern.slf4j.Slf4j;

@Controller
@Transactional
@Slf4j
public class ImportController {
	@Autowired
	private LogImportDAO logImportDao;
	@Autowired
	private ExcellUtils excellUtils;
	@Autowired
	private ImportToolService importService;
	
	@GetMapping(value = "/importTool")
	public String viewImportTool(Model model) {
		List<LogImport> logs = logImportDao.findAll();
		
		model.addAttribute("logs", logs);
		return "importTool/importTool";
	}
	
	@PostMapping(value="/importTool")
	public String importTool(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
		List<Object[]> lstResult = excellUtils.readExcel4LoadData(file);
		importService.storeData(lstResult, file);
		return "redirect:/ctidList";
	}
	
	@PostMapping("/import/loadData")
	@ResponseBody
	public List<Object[]> changeFileImport(Long templateId, @RequestParam("file") MultipartFile fileImport) throws Exception {
		try {
			List<Object[]> lstResult = new ArrayList<>();
			// read excel
			lstResult = excellUtils.readExcel4LoadData(fileImport);
			// return list object
			return lstResult;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
	}
	
	@PostMapping("/import/validateExcel")
	@ResponseBody
	public ResponseEntity<?> validateExcel(Long templateId, @RequestParam("file") MultipartFile fileImport) throws Exception {
		try {
			// return list object
			List<Object[]> lstReadExcel = excellUtils.readExcel4LoadData(fileImport);
			Map<String, Object> response = new HashMap<>();
			response.put("message", excellUtils.validateExcell(lstReadExcel));
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
	}
	
	@GetMapping("/dowload/{id}")
	public void downloadFileImport(@PathVariable Long id, HttpServletResponse response) throws Exception {
		
		OutputStream out = response.getOutputStream();
		File fileImport = importService.getFileUpload(id);
        if (fileImport == null) {
        	response.setContentType("application/x-download");
            response.setHeader("Content-disposition", "form-data;");
        	return;
        }
        response.setContentType("application/x-download");
        response.setHeader("Content-disposition", "attachment; filename=" + fileImport.getName());
        if (fileImport.exists()) {
            InputStream in = new FileInputStream(fileImport);
            int c = 0;
            while ((c = in.read()) != -1) {
                out.write(c);
            }
            out.flush();
            out.close();
            in.close();
            fileImport.delete();
        }
    }
	
	@GetMapping("/import/checkExistFileImport")
	@ResponseBody
	public ResponseEntity<Boolean> checkExistFileImport(Long logId) throws Exception{
		LogImport logImport = logImportDao.findToolById(logId);
    	if (logImport.getByteFileImport() != null) {
			return ResponseEntity.ok(Boolean.TRUE);
		}
		return ResponseEntity.ok(Boolean.FALSE);
	}
}
