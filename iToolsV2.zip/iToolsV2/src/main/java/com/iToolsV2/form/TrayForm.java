package com.iToolsV2.form;

public class TrayForm {
	private String machineCode;
    private String tray01;
    private String tray02;
    private String tray03;
    private String tray04;
    private String tray05;
    private String tray06;
    private String tray07;
    private String tray08;
    private String tray09;
    private String tray10;
    private String tray11;
    private String tray12;
    private String tray13;
    private String tray14;
    private String tray15;
    private String tray16;
    private String tray17;
    private String tray18;
    private String tray19;
    private String tray20;
    private String tray21;
    private String tray22;
    private String tray23;
    private String tray24;
    private String tray25;
    private String tray26;
    private String tray27;
    private String tray28;
    private String tray29;
    private String tray30;
    private String tray31;
    private String tray32;
    private String tray33;
    private String tray34;
    private String tray35;
    private String tray36;
    private String tray37;
    private String tray38;
    private String tray39;
    private String tray40;
    private String tray41;
    private String tray42;
    private String tray43;
    private String tray44;
    private String tray45;
    private String tray46;
    private String tray47;
    private String tray48;
    private String tray49;
    private String tray50;
    private String tray51;
    private String tray52;
    private String tray53;
    private String tray54;
    private String tray55;
    private String tray56;
    private String tray57;
    private String tray58;
    private String tray59;
    private String tray60;
    private int quantity01;
    private int quantity02;
    private int quantity03;
    private int quantity04;
    private int quantity05;
    private int quantity06;
    private int quantity07;
    private int quantity08;
    private int quantity09;
    private int quantity10;
    private int quantity11;
    private int quantity12;
    private int quantity13;
    private int quantity14;
    private int quantity15;
    private int quantity16;
    private int quantity17;
    private int quantity18;
    private int quantity19;
    private int quantity20;
    private int quantity21;
    private int quantity22;
    private int quantity23;
    private int quantity24;
    private int quantity25;
    private int quantity26;
    private int quantity27;
    private int quantity28;
    private int quantity29;
    private int quantity30;
    private int quantity31;
    private int quantity32;
    private int quantity33;
    private int quantity34;
    private int quantity35;
    private int quantity36;
    private int quantity37;
    private int quantity38;
    private int quantity39;
    private int quantity40;
    private int quantity41;
    private int quantity42;
    private int quantity43;
    private int quantity44;
    private int quantity45;
    private int quantity46;
    private int quantity47;
    private int quantity48;
    private int quantity49;
    private int quantity50;
    private int quantity51;
    private int quantity52;
    private int quantity53;
    private int quantity54;
    private int quantity55;
    private int quantity56;
    private int quantity57;
    private int quantity58;
    private int quantity59;
    private int quantity60;

    public TrayForm() {

    }

	public String getMachineCode() {
		return machineCode;
	}
	
	public void setMachineCode(String machineCode) {
		this.machineCode = machineCode;
	}

	public String getTray01() {
		return tray01;
	}

	public void setTray01(String tray01) {
		this.tray01 = tray01;
	}

	public String getTray02() {
		return tray02;
	}

	public void setTray02(String tray02) {
		this.tray02 = tray02;
	}

	public String getTray03() {
		return tray03;
	}

	public void setTray03(String tray03) {
		this.tray03 = tray03;
	}

	public String getTray04() {
		return tray04;
	}

	public void setTray04(String tray04) {
		this.tray04 = tray04;
	}

	public String getTray05() {
		return tray05;
	}

	public void setTray05(String tray05) {
		this.tray05 = tray05;
	}

	public String getTray06() {
		return tray06;
	}

	public void setTray06(String tray06) {
		this.tray06 = tray06;
	}

	public String getTray07() {
		return tray07;
	}

	public void setTray07(String tray07) {
		this.tray07 = tray07;
	}

	public String getTray08() {
		return tray08;
	}

	public void setTray08(String tray08) {
		this.tray08 = tray08;
	}

	public String getTray09() {
		return tray09;
	}

	public void setTray09(String tray09) {
		this.tray09 = tray09;
	}

	public String getTray10() {
		return tray10;
	}

	public void setTray10(String tray10) {
		this.tray10 = tray10;
	}

	public String getTray11() {
		return tray11;
	}

	public void setTray11(String tray11) {
		this.tray11 = tray11;
	}

	public String getTray12() {
		return tray12;
	}

	public void setTray12(String tray12) {
		this.tray12 = tray12;
	}

	public String getTray13() {
		return tray13;
	}

	public void setTray13(String tray13) {
		this.tray13 = tray13;
	}

	public String getTray14() {
		return tray14;
	}

	public void setTray14(String tray14) {
		this.tray14 = tray14;
	}

	public String getTray15() {
		return tray15;
	}

	public void setTray15(String tray15) {
		this.tray15 = tray15;
	}

	public String getTray16() {
		return tray16;
	}

	public void setTray16(String tray16) {
		this.tray16 = tray16;
	}

	public String getTray17() {
		return tray17;
	}

	public void setTray17(String tray17) {
		this.tray17 = tray17;
	}

	public String getTray18() {
		return tray18;
	}

	public void setTray18(String tray18) {
		this.tray18 = tray18;
	}

	public String getTray19() {
		return tray19;
	}

	public void setTray19(String tray19) {
		this.tray19 = tray19;
	}

	public String getTray20() {
		return tray20;
	}

	public void setTray20(String tray20) {
		this.tray20 = tray20;
	}

	public String getTray21() {
		return tray21;
	}

	public void setTray21(String tray21) {
		this.tray21 = tray21;
	}

	public String getTray22() {
		return tray22;
	}

	public void setTray22(String tray22) {
		this.tray22 = tray22;
	}

	public String getTray23() {
		return tray23;
	}

	public void setTray23(String tray23) {
		this.tray23 = tray23;
	}

	public String getTray24() {
		return tray24;
	}

	public void setTray24(String tray24) {
		this.tray24 = tray24;
	}

	public String getTray25() {
		return tray25;
	}

	public void setTray25(String tray25) {
		this.tray25 = tray25;
	}

	public String getTray26() {
		return tray26;
	}

	public void setTray26(String tray26) {
		this.tray26 = tray26;
	}

	public String getTray27() {
		return tray27;
	}

	public void setTray27(String tray27) {
		this.tray27 = tray27;
	}

	public String getTray28() {
		return tray28;
	}

	public void setTray28(String tray28) {
		this.tray28 = tray28;
	}

	public String getTray29() {
		return tray29;
	}

	public void setTray29(String tray29) {
		this.tray29 = tray29;
	}

	public String getTray30() {
		return tray30;
	}

	public void setTray30(String tray30) {
		this.tray30 = tray30;
	}

	public String getTray31() {
		return tray31;
	}

	public void setTray31(String tray31) {
		this.tray31 = tray31;
	}

	public String getTray32() {
		return tray32;
	}

	public void setTray32(String tray32) {
		this.tray32 = tray32;
	}

	public String getTray33() {
		return tray33;
	}

	public void setTray33(String tray33) {
		this.tray33 = tray33;
	}

	public String getTray34() {
		return tray34;
	}

	public void setTray34(String tray34) {
		this.tray34 = tray34;
	}

	public String getTray35() {
		return tray35;
	}

	public void setTray35(String tray35) {
		this.tray35 = tray35;
	}

	public String getTray36() {
		return tray36;
	}

	public void setTray36(String tray36) {
		this.tray36 = tray36;
	}

	public String getTray37() {
		return tray37;
	}

	public void setTray37(String tray37) {
		this.tray37 = tray37;
	}

	public String getTray38() {
		return tray38;
	}

	public void setTray38(String tray38) {
		this.tray38 = tray38;
	}

	public String getTray39() {
		return tray39;
	}

	public void setTray39(String tray39) {
		this.tray39 = tray39;
	}

	public String getTray40() {
		return tray40;
	}

	public void setTray40(String tray40) {
		this.tray40 = tray40;
	}

	public String getTray41() {
		return tray41;
	}

	public void setTray41(String tray41) {
		this.tray41 = tray41;
	}

	public String getTray42() {
		return tray42;
	}

	public void setTray42(String tray42) {
		this.tray42 = tray42;
	}

	public String getTray43() {
		return tray43;
	}

	public void setTray43(String tray43) {
		this.tray43 = tray43;
	}

	public String getTray44() {
		return tray44;
	}

	public void setTray44(String tray44) {
		this.tray44 = tray44;
	}

	public String getTray45() {
		return tray45;
	}

	public void setTray45(String tray45) {
		this.tray45 = tray45;
	}

	public String getTray46() {
		return tray46;
	}

	public void setTray46(String tray46) {
		this.tray46 = tray46;
	}

	public String getTray47() {
		return tray47;
	}

	public void setTray47(String tray47) {
		this.tray47 = tray47;
	}

	public String getTray48() {
		return tray48;
	}

	public void setTray48(String tray48) {
		this.tray48 = tray48;
	}

	public String getTray49() {
		return tray49;
	}

	public void setTray49(String tray49) {
		this.tray49 = tray49;
	}

	public String getTray50() {
		return tray50;
	}

	public void setTray50(String tray50) {
		this.tray50 = tray50;
	}

	public String getTray51() {
		return tray51;
	}

	public void setTray51(String tray51) {
		this.tray51 = tray51;
	}

	public String getTray52() {
		return tray52;
	}

	public void setTray52(String tray52) {
		this.tray52 = tray52;
	}

	public String getTray53() {
		return tray53;
	}

	public void setTray53(String tray53) {
		this.tray53 = tray53;
	}

	public String getTray54() {
		return tray54;
	}

	public void setTray54(String tray54) {
		this.tray54 = tray54;
	}

	public String getTray55() {
		return tray55;
	}

	public void setTray55(String tray55) {
		this.tray55 = tray55;
	}

	public String getTray56() {
		return tray56;
	}

	public void setTray56(String tray56) {
		this.tray56 = tray56;
	}

	public String getTray57() {
		return tray57;
	}

	public void setTray57(String tray57) {
		this.tray57 = tray57;
	}

	public String getTray58() {
		return tray58;
	}

	public void setTray58(String tray58) {
		this.tray58 = tray58;
	}

	public String getTray59() {
		return tray59;
	}

	public void setTray59(String tray59) {
		this.tray59 = tray59;
	}

	public String getTray60() {
		return tray60;
	}

	public void setTray60(String tray60) {
		this.tray60 = tray60;
	}

	public int getQuantity01() {
		return quantity01;
	}

	public void setQuantity01(int quantity01) {
		this.quantity01 = quantity01;
	}

	public int getQuantity02() {
		return quantity02;
	}

	public void setQuantity02(int quantity02) {
		this.quantity02 = quantity02;
	}

	public int getQuantity03() {
		return quantity03;
	}

	public void setQuantity03(int quantity03) {
		this.quantity03 = quantity03;
	}

	public int getQuantity04() {
		return quantity04;
	}

	public void setQuantity04(int quantity04) {
		this.quantity04 = quantity04;
	}

	public int getQuantity05() {
		return quantity05;
	}

	public void setQuantity05(int quantity05) {
		this.quantity05 = quantity05;
	}

	public int getQuantity06() {
		return quantity06;
	}

	public void setQuantity06(int quantity06) {
		this.quantity06 = quantity06;
	}

	public int getQuantity07() {
		return quantity07;
	}

	public void setQuantity07(int quantity07) {
		this.quantity07 = quantity07;
	}

	public int getQuantity08() {
		return quantity08;
	}

	public void setQuantity08(int quantity08) {
		this.quantity08 = quantity08;
	}

	public int getQuantity09() {
		return quantity09;
	}

	public void setQuantity09(int quantity09) {
		this.quantity09 = quantity09;
	}

	public int getQuantity10() {
		return quantity10;
	}

	public void setQuantity10(int quantity10) {
		this.quantity10 = quantity10;
	}

	public int getQuantity11() {
		return quantity11;
	}

	public void setQuantity11(int quantity11) {
		this.quantity11 = quantity11;
	}

	public int getQuantity12() {
		return quantity12;
	}

	public void setQuantity12(int quantity12) {
		this.quantity12 = quantity12;
	}

	public int getQuantity13() {
		return quantity13;
	}

	public void setQuantity13(int quantity13) {
		this.quantity13 = quantity13;
	}

	public int getQuantity14() {
		return quantity14;
	}

	public void setQuantity14(int quantity14) {
		this.quantity14 = quantity14;
	}

	public int getQuantity15() {
		return quantity15;
	}

	public void setQuantity15(int quantity15) {
		this.quantity15 = quantity15;
	}

	public int getQuantity16() {
		return quantity16;
	}

	public void setQuantity16(int quantity16) {
		this.quantity16 = quantity16;
	}

	public int getQuantity17() {
		return quantity17;
	}

	public void setQuantity17(int quantity17) {
		this.quantity17 = quantity17;
	}

	public int getQuantity18() {
		return quantity18;
	}

	public void setQuantity18(int quantity18) {
		this.quantity18 = quantity18;
	}

	public int getQuantity19() {
		return quantity19;
	}

	public void setQuantity19(int quantity19) {
		this.quantity19 = quantity19;
	}

	public int getQuantity20() {
		return quantity20;
	}

	public void setQuantity20(int quantity20) {
		this.quantity20 = quantity20;
	}

	public int getQuantity21() {
		return quantity21;
	}

	public void setQuantity21(int quantity21) {
		this.quantity21 = quantity21;
	}

	public int getQuantity22() {
		return quantity22;
	}

	public void setQuantity22(int quantity22) {
		this.quantity22 = quantity22;
	}

	public int getQuantity23() {
		return quantity23;
	}

	public void setQuantity23(int quantity23) {
		this.quantity23 = quantity23;
	}

	public int getQuantity24() {
		return quantity24;
	}

	public void setQuantity24(int quantity24) {
		this.quantity24 = quantity24;
	}

	public int getQuantity25() {
		return quantity25;
	}

	public void setQuantity25(int quantity25) {
		this.quantity25 = quantity25;
	}

	public int getQuantity26() {
		return quantity26;
	}

	public void setQuantity26(int quantity26) {
		this.quantity26 = quantity26;
	}

	public int getQuantity27() {
		return quantity27;
	}

	public void setQuantity27(int quantity27) {
		this.quantity27 = quantity27;
	}

	public int getQuantity28() {
		return quantity28;
	}

	public void setQuantity28(int quantity28) {
		this.quantity28 = quantity28;
	}

	public int getQuantity29() {
		return quantity29;
	}

	public void setQuantity29(int quantity29) {
		this.quantity29 = quantity29;
	}

	public int getQuantity30() {
		return quantity30;
	}

	public void setQuantity30(int quantity30) {
		this.quantity30 = quantity30;
	}

	public int getQuantity31() {
		return quantity31;
	}

	public void setQuantity31(int quantity31) {
		this.quantity31 = quantity31;
	}

	public int getQuantity32() {
		return quantity32;
	}

	public void setQuantity32(int quantity32) {
		this.quantity32 = quantity32;
	}

	public int getQuantity33() {
		return quantity33;
	}

	public void setQuantity33(int quantity33) {
		this.quantity33 = quantity33;
	}

	public int getQuantity34() {
		return quantity34;
	}

	public void setQuantity34(int quantity34) {
		this.quantity34 = quantity34;
	}

	public int getQuantity35() {
		return quantity35;
	}

	public void setQuantity35(int quantity35) {
		this.quantity35 = quantity35;
	}

	public int getQuantity36() {
		return quantity36;
	}

	public void setQuantity36(int quantity36) {
		this.quantity36 = quantity36;
	}

	public int getQuantity37() {
		return quantity37;
	}

	public void setQuantity37(int quantity37) {
		this.quantity37 = quantity37;
	}

	public int getQuantity38() {
		return quantity38;
	}

	public void setQuantity38(int quantity38) {
		this.quantity38 = quantity38;
	}

	public int getQuantity39() {
		return quantity39;
	}

	public void setQuantity39(int quantity39) {
		this.quantity39 = quantity39;
	}

	public int getQuantity40() {
		return quantity40;
	}

	public void setQuantity40(int quantity40) {
		this.quantity40 = quantity40;
	}

	public int getQuantity41() {
		return quantity41;
	}

	public void setQuantity41(int quantity41) {
		this.quantity41 = quantity41;
	}

	public int getQuantity42() {
		return quantity42;
	}

	public void setQuantity42(int quantity42) {
		this.quantity42 = quantity42;
	}

	public int getQuantity43() {
		return quantity43;
	}

	public void setQuantity43(int quantity43) {
		this.quantity43 = quantity43;
	}

	public int getQuantity44() {
		return quantity44;
	}

	public void setQuantity44(int quantity44) {
		this.quantity44 = quantity44;
	}

	public int getQuantity45() {
		return quantity45;
	}

	public void setQuantity45(int quantity45) {
		this.quantity45 = quantity45;
	}

	public int getQuantity46() {
		return quantity46;
	}

	public void setQuantity46(int quantity46) {
		this.quantity46 = quantity46;
	}

	public int getQuantity47() {
		return quantity47;
	}

	public void setQuantity47(int quantity47) {
		this.quantity47 = quantity47;
	}

	public int getQuantity48() {
		return quantity48;
	}

	public void setQuantity48(int quantity48) {
		this.quantity48 = quantity48;
	}

	public int getQuantity49() {
		return quantity49;
	}

	public void setQuantity49(int quantity49) {
		this.quantity49 = quantity49;
	}

	public int getQuantity50() {
		return quantity50;
	}

	public void setQuantity50(int quantity50) {
		this.quantity50 = quantity50;
	}

	public int getQuantity51() {
		return quantity51;
	}

	public void setQuantity51(int quantity51) {
		this.quantity51 = quantity51;
	}

	public int getQuantity52() {
		return quantity52;
	}

	public void setQuantity52(int quantity52) {
		this.quantity52 = quantity52;
	}

	public int getQuantity53() {
		return quantity53;
	}

	public void setQuantity53(int quantity53) {
		this.quantity53 = quantity53;
	}

	public int getQuantity54() {
		return quantity54;
	}

	public void setQuantity54(int quantity54) {
		this.quantity54 = quantity54;
	}

	public int getQuantity55() {
		return quantity55;
	}

	public void setQuantity55(int quantity55) {
		this.quantity55 = quantity55;
	}

	public int getQuantity56() {
		return quantity56;
	}

	public void setQuantity56(int quantity56) {
		this.quantity56 = quantity56;
	}

	public int getQuantity57() {
		return quantity57;
	}

	public void setQuantity57(int quantity57) {
		this.quantity57 = quantity57;
	}

	public int getQuantity58() {
		return quantity58;
	}

	public void setQuantity58(int quantity58) {
		this.quantity58 = quantity58;
	}

	public int getQuantity59() {
		return quantity59;
	}

	public void setQuantity59(int quantity59) {
		this.quantity59 = quantity59;
	}

	public int getQuantity60() {
		return quantity60;
	}

	public void setQuantity60(int quantity60) {
		this.quantity60 = quantity60;
	}

}