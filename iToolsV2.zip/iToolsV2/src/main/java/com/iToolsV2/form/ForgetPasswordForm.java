package com.iToolsV2.form;

import lombok.Data;

@Data
public class ForgetPasswordForm {
    private String username;
    private String email;
}
