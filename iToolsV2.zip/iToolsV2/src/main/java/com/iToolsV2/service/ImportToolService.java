package com.iToolsV2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.iToolsV2.dao.LogImportDAO;
import com.iToolsV2.dao.ToolDAO;
import com.iToolsV2.entity.LogImport;
import com.iToolsV2.entity.Tools;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ImportToolService {
	@Autowired
	private LogImportDAO logImportDAO;
	@Value("${base.folder.temptFolfer}")
	private String folderTempt;
	@Autowired
	private ToolDAO toolDao;
	
	public File getFileUpload(Long logId) throws Exception {
    	try {
    		// get file from database
        	LogImport logImport = logImportDAO.findToolById(logId);
        	if (logImport.getByteFileImport() == null) {
        		return null;
        	}
        	
        	File tempt = new File(folderTempt);
    		if (!tempt.exists()) {
    			tempt.mkdirs();
    		}
        	
        	String filePathTempt = folderTempt + File.separator + logImport.getFileName();
        	OutputStream targetFile=  new FileOutputStream(filePathTempt);
            targetFile.write(logImport.getByteFileImport());
            targetFile.close();
        	
        	return new File(filePathTempt);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
    }
	
	public void storeData(List<Object[]> lstObject) throws Exception {
		try {
			if (lstObject != null) {
				for (Object[] obj : lstObject) {
					Tools tool = new Tools();
					tool.setToolCode((String) obj[0]);
					tool.setModel((String) obj[1]);
					tool.setDescription((String) obj[2]);
					String strStatus = (String) obj[3];
					if ("0".equals(strStatus)) {
						tool.setActive(false);
					} else {
						tool.setActive(true);
					}
					tool.setCreatedDate(new Date());
					tool.setUpdatedDate(new Date());
					toolDao.saveTool(tool);
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
	}
}
