package com.iToolsV2.dao;
 
import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.iToolsV2.entity.LogImport;
 
@Transactional
@Repository
public class LogImportDAO {
 
    @Autowired
    //private EntityManager entityManager;
    private SessionFactory sessionFactory;
    
    public LogImport findToolById(Long logId) {
    	LogImport log = null;
        try {
        	Session session = this.sessionFactory.getCurrentSession();
        	 String sql = "from " + LogImport.class.getName() + " LogImport " //
                     + " Where LogImport.id = :id ";
             Query<LogImport> query = session.createQuery(sql, LogImport.class);
             query.setParameter("id", logId);
             log = query.getSingleResult();
        } catch (Exception e) {
           e.printStackTrace();
        } 
        return log;
    }
    
    public LogImport saveLogImport(LogImport log) {
    	Session session = this.sessionFactory.getCurrentSession();
    	session.persist(log);
        session.flush();
        return log;
    }
    
    public List<LogImport> findAll() {
    	try {
	    	Session session = this.sessionFactory.getCurrentSession();
	        String sql = "from " + LogImport.class.getName() + " import_log ";
	        Query<LogImport> query = session.createQuery(sql, LogImport.class);
	        return query.getResultList();
    	} catch (NoResultException e) {
    		return null;
    	}
    }
 
}