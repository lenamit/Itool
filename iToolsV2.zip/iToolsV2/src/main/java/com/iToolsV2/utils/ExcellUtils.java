package com.iToolsV2.utils;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ExcellUtils {
	public String validateExcell(List<Object[]> lstObject) throws Exception {
		Workbook workbook = null;
		try {
			if (lstObject != null) {
				int rowIndex = 0;
				String messageReturn = "Các dòng thứ";
				String message = "";
				boolean validated = true;
				for (Object[] object : lstObject) {
					rowIndex ++;
					if (object.length > 3) {
						if (object[0] == null || String.valueOf(object[0]).isEmpty()) {
							validated = false;
							if (message.isEmpty()) {
								message += " " + rowIndex;
							} else {
								message += ", " + rowIndex;
							}
						}
					} else {
						validated = false;
						if (message.isEmpty()) {
							message += " " + rowIndex;
						} else {
							message += ", " + rowIndex;
						}
					}
				}
				if (validated) {
					messageReturn += message + " có chứa field \"code\" không được trống !\nVui lòng kiểm tra lại !";
					return messageReturn;
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			if (workbook!=null) {workbook.close(); workbook =null;}
		}
		return "TRUE";
	}
	
	public List<Object[]> readExcel4LoadData(MultipartFile fileImport) throws Exception {
    	Workbook workbook = null;
    	List<Object[]> lstResutl = new ArrayList<>();
    	try {
    		DataFormatter formatter = new DataFormatter();
    		InputStream is = fileImport.getInputStream();
    		workbook = WorkbookFactory.create(is);
    		Sheet sheet0 = workbook.getSheetAt(0);
    		for (Row currentRow : sheet0) {
    			int size = currentRow.getLastCellNum();
				Object[] rowData = new Object[size];
				for (int cellIndex = 0; cellIndex < size; cellIndex++) {
					Cell currentCell = currentRow.getCell(cellIndex);
					String strValueCellDefault = formatter.formatCellValue(currentCell);
					rowData[cellIndex] = strValueCellDefault;
				}
				lstResutl.add(rowData);
    		}
    		
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		} finally {
			if (workbook!=null) {workbook.close(); workbook =null;}
		}
    	
    	return lstResutl;
    }
}
