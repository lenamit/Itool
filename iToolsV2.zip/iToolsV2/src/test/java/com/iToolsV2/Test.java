package com.iToolsV2;

import org.springframework.security.crypto.password.PasswordEncoder;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
